using UnityEngine;

public class UpgradeManager : MonoBehaviour
{
    public int largerInventoryCost = 50;
    public Inventory inventory;

    public bool PurchaseUpgrade(string upgradeType, ref int playerMoney)
    {
        if (upgradeType == "LargerInventory" && playerMoney >= largerInventoryCost)
        {
            playerMoney -= largerInventoryCost;
            inventory.maxStock += 5;
            inventory.ResetDailyStock();
            return true;
        }

        return false;
    }
}

using UnityEngine;
using System.Collections.Generic;

public class Inventory : MonoBehaviour
{
    public Dictionary<string, int> stock = new Dictionary<string, int>()
    {
        {"Nougat Bar", 5},
        {"Chocolate Bar", 5},
        {"Gummies", 5},
        {"Slushie", 5},
        {"Beverage Can", 12},
        {"Popcorn", 5},
        {"Hotdog", 10}
    };

    public Dictionary<string, float> prices = new Dictionary<string, float>()
    {
        {"Nougat Bar", 3.0f},
        {"Chocolate Bar", 3.0f},
        {"Gummies", 3.0f},
        {"Slushie", 3.5f},
        {"Beverage Can", 2.5f},
        {"Popcorn", 4.0f},
        {"Hotdog", 5.0f}
    };

    public int maxStock = 10;

    public void ResetDailyStock()
    {
        foreach (var item in stock.Keys)
        {
            stock[item] = maxStock;
        }
    }

    public int ProcessOrder(List<string> order)
    {
        int totalValue = 0;
        int itemsOutOfStock = 0;

        foreach (string item in order)
        {
            if (stock.ContainsKey(item) && stock[item] > 0)
            {
                totalValue += (int)prices[item];
                stock[item]--;
            }
            else
            {
                itemsOutOfStock++;
            }
        }

        return itemsOutOfStock >= 2 ? 0 : totalValue;
    }

    public bool RestockItem(string item, int quantity)
    {
        if (stock.ContainsKey(item) && stock[item] + quantity <= maxStock)
        {
            stock[item] += quantity;
            return true;
        }

        return false;
    }

    public int GetRestockCost(string item, int quantity)
    {
        return stock.ContainsKey(item) ? (int)(prices[item] * quantity) : 0;
    }
}

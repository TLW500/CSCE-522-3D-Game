using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;

public class GameController : MonoBehaviour
{
    public int dayNumber = 1;
    public int dailyCustomers = 5;
    public int restockLimit = 3; 
    public int money = 100;
    public int stockSizeCost = 105; 
    public bool maxStockSizeReached = false; 
    public int dailyRestocksCost = 75;
    public bool maxDailyRestocksReached = false; 
    public int dailyRestocksLeft = 3;

    public TextMeshProUGUI dayText;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI customerOrderText;
    public TextMeshProUGUI messageText;

    public GameObject mainMenu;
    public GameObject pauseMenu;
    public GameObject gameOverMenu;
    public GameObject registerMenuPanel; 

    public Inventory inventory;
    public Customer customer;
    public CustomerSpawner customerSpawner;
    public UpgradeManager upgradeManager;
    public CustomerOrderDisplay customerOrderDisplay;
    public InventoryDisplay inventoryDisplay;

    public int customersServed;
    public int restocksUsed;
    public bool isDayOver;

    public Dropdown itemDropdown;
    public Button restockButton;
    public Button increaseStockSizeButton;
    public Button increaseRestocksButton;

    void Start()
    {
        StartNewDay();
        InitializeRegisterMenu();
    }
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (money <= 0 && !isDayOver)
        {
            GameOver();
        }
    }

    public void StartNewDay()
    {
        isDayOver = false;
        dayText.text = "Day: " + dayNumber;
        moneyText.text = "Money: $" + money;
        customersServed = 0;
        restocksUsed = 0;
        inventory.ResetDailyStock();
        customerSpawner.SpawnNextCustomer();  
        inventoryDisplay.RefreshInventory(inventory);
    }

    public void ServeCustomer(Customer customer)
    {
        customerOrderDisplay.DisplayOrder(customer.order, customerOrderText, inventory.prices);
        StartCoroutine(HandleCustomerOrder(customer));
    }

    private IEnumerator<WaitForSeconds> HandleCustomerOrder(Customer customer)
    {
        Debug.Log("Serving customer order: " + string.Join(", ", customer.order));
        
        int orderValue = inventory.ProcessOrder(customer.order);

        if (orderValue > 0)
        {
            Debug.Log("Order processed. Total value: $" + orderValue);
            money += orderValue;
            moneyText.text = "Money: $" + money;
            inventoryDisplay.RefreshInventory(inventory);

            customer.MoveToPointB();
            yield return new WaitForSeconds(5);

            customersServed++;
            Debug.Log("Customers served: " + customersServed);

            customer.MoveToPointA();
            yield return new WaitForSeconds(5);
            customer.Despawn();
        }
        else
        {
            // Display an error message
            messageText.text = "One or more customer items are out of stock!";
            yield return new WaitForSeconds(5);
            messageText.text = "";
        }

        // Check if the day is over
        if (customersServed >= dailyCustomers)
        {
            EndDay();
        }
        else
        {
            customerSpawner.SpawnNextCustomer();
        }
    }

    public void ToggleRegisterMenu()
    {
        registerMenuPanel.SetActive(!registerMenuPanel.activeSelf);
        Time.timeScale = registerMenuPanel.activeSelf ? 0 : 1;
    }

    void InitializeRegisterMenu()
    {
        increaseStockSizeButton.onClick.AddListener(() => PurchaseUpgrade("LargerInventory"));
        increaseRestocksButton.onClick.AddListener(() => PurchaseUpgrade("AdditionalRestock"));
        restockButton.onClick.AddListener(RestockSelectedItem);
        UpdateRegisterMenuButtons();
    }

    public void UpdateRegisterMenuButtons()
    {
        increaseStockSizeButton.interactable = money >= 100 && !upgradeManager.HasMaxUpgrade("LargerInventory");
        increaseRestocksButton.interactable = money >= 50 && !upgradeManager.HasMaxUpgrade("AdditionalRestock");
        restockButton.interactable = restocksUsed < restockLimit && dailyRestocksLeft > 0;
    }

    public void RestockSelectedItem()
    {
        string item = itemDropdown.options[itemDropdown.value].text;
        int quantity = 1;
        RestockItems(item, quantity);
    }

    public void RestockItems(string item, int quantity)
    {
        if (restocksUsed < restockLimit && inventory.RestockItem(item, quantity))
        {
            restocksUsed++;
            moneyText.text = "Money: $" + money;
            UpdateRegisterMenuButtons();
        }
        else if (restocksUsed >= restockLimit && upgradeManager.additionalRestocksPurchased < upgradeManager.maxAdditionalRestocks)
        {
            if (restocksUsed < restockLimit + upgradeManager.additionalRestocksPurchased)
            {
                restocksUsed++;
                moneyText.text = "Money: $" + money;
                UpdateRegisterMenuButtons();
            }
        }
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        if (upgradeManager.PurchaseUpgrade(upgradeType, ref money))
        {
            moneyText.text = "Money: $" + money;

            if (upgradeType == "LargerInventory")
            {
                restockLimit++;
                inventoryDisplay.RefreshInventory(inventory);
            }
            else if (upgradeType == "AdditionalRestock")
            {
                restockLimit++;
            }

            UpdateRegisterMenuButtons();
        }
    }

    void EndDay()
    {
        isDayOver = true;
        money -= 50;
        if (money <= 0)
        {
            GameOver();
        }
        else
        {
            dayNumber++;
            StartNewDay();
        }
    }
    
    void GameOver()
    {
        gameOverMenu.SetActive(true);
    }

    void TogglePauseMenu()
    {
        pauseMenu.SetActive(!pauseMenu.activeSelf);
        Time.timeScale = pauseMenu.activeSelf ? 0 : 1;
    }
}

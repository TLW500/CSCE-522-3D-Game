using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public int dayNumber = 1;
    public int dailyCustomers = 5;
    public int restockLimit = 3;
    public int money = 100;

    public Text dayText;
    public Text moneyText;
    public Text customerOrderText;

    public GameObject mainMenu;
    public GameObject pauseMenu;
    public GameObject gameOverMenu;

    public Inventory inventory;
    public CustomerSpawner customerSpawner;
    public UpgradeManager upgradeManager;

    private int customersServed;
    private int restocksUsed;

    void Start()
    {
        StartNewDay();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (money <= 0)
        {
            GameOver();
        }
    }

    public void StartNewDay()
    {
        dayText.text = "Day: " + dayNumber;
        moneyText.text = "Money: $" + money;
        customersServed = 0;
        restocksUsed = 0;
        inventory.ResetDailyStock();
        customerSpawner.SpawnCustomer();
    }

    public void ServeCustomer(Customer customer)
    {
        int orderValue = inventory.ProcessOrder(customer.order);

        if (orderValue > 0)
        {
            money += orderValue;
        }

        customersServed++;
        moneyText.text = "Money: $" + money;

        if (customersServed >= dailyCustomers)
        {
            EndDay();
        }
    }

    public void RestockItems(string item, int quantity)
    {
        int restockCost = inventory.GetRestockCost(item, quantity);

        if (restocksUsed < restockLimit && money >= restockCost && inventory.RestockItem(item, quantity))
        {
            money -= restockCost;
            restocksUsed++;
            moneyText.text = "Money: $" + money;
        }
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        if (upgradeManager.PurchaseUpgrade(upgradeType, ref money))
        {
            moneyText.text = "Money: $" + money;
        }
    }

    void EndDay()
    {
        dayNumber++;
        StartNewDay();
    }

    void GameOver()
    {
        gameOverMenu.SetActive(true);
    }

    void TogglePauseMenu()
    {
        pauseMenu.SetActive(!pauseMenu.activeSelf);
        Time.timeScale = pauseMenu.activeSelf ? 0 : 1;
    }
}

using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class GameController : MonoBehaviour
{
    public int dayNumber = 1;
    public int dailyCustomers = 5;
    public int restockLimit = 3;
    public int money = 100;

    public Text dayText;
    public Text moneyText;
    public Text customerOrderText;
    public Text messageText;

    public GameObject mainMenu;
    public GameObject pauseMenu;
    public GameObject gameOverMenu;

    public Inventory inventory;
    public CustomerSpawner customerSpawner;
    public UpgradeManager upgradeManager;

    public int customersServed;
    public int restocksUsed;
    public bool isDayOver;

    void Start()
    {
        StartNewDay();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (money <= 0 && !isDayOver)
        {
            GameOver();
        }
    }

    public void StartNewDay()
    {
        isDayOver = false;
        dayText.text = "Day: " + dayNumber;
        moneyText.text = "Money: $" + money;
        customersServed = 0;
        restocksUsed = 0;
        inventory.ResetDailyStock();
        customerSpawner.SpawnNextCustomer();
    }

    public void ServeCustomer(Customer customer)
    {
        customerOrderText.text = "Customer Order: " + string.Join(", ", customer.order);
        StartCoroutine(HandleCustomerOrder(customer));
    }

    private IEnumerator<WaitForSeconds> HandleCustomerOrder(Customer customer)
    {
        // Check if the customer order is complete
        int orderValue = inventory.ProcessOrder(customer.order);
        
        if (orderValue > 0)
        {
            money += orderValue;
            moneyText.text = "Money: $" + money;
            
            // Customer moves to point B
            customer.MoveToPointB();

            // Wait 10 seconds at point B (processing the order)
            yield return new WaitForSeconds(10);

            // Process order and subtract items from stock
            inventory.ProcessOrder(customer.order);
            customersServed++;

            // Customer moves back to point A
            customer.MoveToPointA();

            yield return new WaitForSeconds(10);

            // Customer despawns
            Destroy(customer.gameObject);
        }
        else
        {
            // Show message if out of stock
            messageText.text = "One or more customer items are out of stock!";
            yield return new WaitForSeconds(5);
            messageText.text = "";

            // Wait for 30 seconds and spawn next customer
            yield return new WaitForSeconds(30);
        }

        // End of customer handling logic
        if (customersServed >= dailyCustomers)
        {
            EndDay();
        }
        else
        {
            customerSpawner.SpawnNextCustomer();
        }
    }

    public void RestockItems(string item, int quantity)
    {
        int restockCost = inventory.GetRestockCost(item, quantity);

        if (restocksUsed < restockLimit && money >= restockCost && inventory.RestockItem(item, quantity))
        {
            money -= restockCost;
            restocksUsed++;
            moneyText.text = "Money: $" + money;
        }
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        if (upgradeManager.PurchaseUpgrade(upgradeType, ref money))
        {
            moneyText.text = "Money: $" + money;
        }
    }

    void EndDay()
    {
        isDayOver = true;
        money -= 50;  // Deduct $50 at the end of each day
        if (money <= 0)
        {
            GameOver();
        }
        else
        {
            dayNumber++;
            StartNewDay();
        }
    }

    void GameOver()
    {
        gameOverMenu.SetActive(true);
    }

    void TogglePauseMenu()
    {
        pauseMenu.SetActive(!pauseMenu.activeSelf);
        Time.timeScale = pauseMenu.activeSelf ? 0 : 1;
    }
}

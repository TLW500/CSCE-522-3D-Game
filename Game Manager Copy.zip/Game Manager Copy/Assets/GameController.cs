using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class GameController : MonoBehaviour
{
    public int dayNumber = 1;
    public int dailyCustomers = 10;
    public int restockLimit = 3;
    public int money = 100;

    public Text dayText;
    public Text moneyText;
    public Text customerOrderText;

    public GameObject mainMenu;
    public GameObject pauseMenu;
    public GameObject gameOverMenu;

    public Inventory inventory;
    public CustomerSpawner customerSpawner;
    public UpgradeManager upgradeManager;

    private int customersServed;
    private int restocksUsed;

    void Start()
    {
        StartNewDay();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (money <= 0)
        {
            GameOver();
        }
    }

    public void StartNewDay()
    {
        dayText.text = "Day: " + dayNumber;
        moneyText.text = "Money: $" + money;
        customersServed = 0;
        restocksUsed = 0;
        inventory.ResetDailyStock();
        customerSpawner.SpawnCustomers(dailyCustomers);
    }

    public void ServeCustomer(Customer customer)
    {
        int orderValue = inventory.ProcessOrder(customer.order);

        if (orderValue > 0)
        {
            money += orderValue;
        }

        customersServed++;
        moneyText.text = "Money: $" + money;

        if (customersServed >= dailyCustomers)
        {
            EndDay();
        }
    }

    public void RestockItems(string item, int quantity)
    {
        int restockCost = inventory.GetRestockCost(item, quantity);

        if (restocksUsed < restockLimit && money >= restockCost && inventory.RestockItem(item, quantity))
        {
            money -= restockCost;
            restocksUsed++;
            moneyText.text = "Money: $" + money;
        }
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        if (upgradeManager.PurchaseUpgrade(upgradeType, ref money))
        {
            moneyText.text = "Money: $" + money;
        }
    }

    void EndDay()
    {
        dayNumber++;
        StartNewDay();
    }

    void GameOver()
    {
        gameOverMenu.SetActive(true);
    }

    void TogglePauseMenu()
    {
        pauseMenu.SetActive(!pauseMenu.activeSelf);
        Time.timeScale = pauseMenu.activeSelf ? 0 : 1;
    }
}

public class Inventory : MonoBehaviour
{
    public Dictionary<string, int> stock = new Dictionary<string, int>()
    {
        {"Nougat Bar", 5},
        {"Chocolate Bar", 5},
        {"Gummies", 5},
        {"Slushie", 5},
        {"Beverage Can", 12},
        {"Popcorn", 5},
        {"Hotdog", 10}
    };

    public Dictionary<string, float> prices = new Dictionary<string, float>()
    {
        {"Nougat Bar", 3.0f},
        {"Chocolate Bar", 3.0f},
        {"Gummies", 3.0f},
        {"Slushie", 3.5f},
        {"Beverage Can", 2.5f},
        {"Popcorn", 4.0f},
        {"Hotdog", 5.0f}
    };

    public int maxStock = 10;

    public void ResetDailyStock()
    {
        foreach (var item in stock.Keys)
        {
            stock[item] = maxStock;
        }
    }

    public int ProcessOrder(List<string> order)
    {
        int totalValue = 0;
        int itemsOutOfStock = 0;

        foreach (string item in order)
        {
            if (stock.ContainsKey(item) && stock[item] > 0)
            {
                totalValue += (int)prices[item];
                stock[item]--;
            }
            else
            {
                itemsOutOfStock++;
            }
        }

        return itemsOutOfStock >= 2 ? 0 : totalValue;
    }

    public bool RestockItem(string item, int quantity)
    {
        if (stock.ContainsKey(item) && stock[item] + quantity <= maxStock)
        {
            stock[item] += quantity;
            return true;
        }

        return false;
    }

    public int GetRestockCost(string item, int quantity)
    {
        return stock.ContainsKey(item) ? (int)(prices[item] * quantity) : 0;
    }
}

public class CustomerSpawner : MonoBehaviour
{
    public GameObject customerPrefab;

    public void SpawnCustomers(int count)
    {
        for (int i = 0; i < count; i++)
        {
            Instantiate(customerPrefab, transform.position, Quaternion.identity);
        }
    }
}

public class UpgradeManager : MonoBehaviour
{
    public int largerInventoryCost = 50;
    public Inventory inventory;

    public bool PurchaseUpgrade(string upgradeType, ref int playerMoney)
    {
        if (upgradeType == "LargerInventory" && playerMoney >= largerInventoryCost)
        {
            playerMoney -= largerInventoryCost;
            inventory.maxStock += 5;
            inventory.ResetDailyStock();
            return true;
        }

        return false;
    }
}

public class Customer : MonoBehaviour
{
    public List<string> order;

    void Start()
    {
        GenerateOrder();
    }

    void GenerateOrder()
    {
        int orderSize = Random.Range(3, 6);
        order = new List<string>();

        List<string> items = new List<string>() { "Nougat Bar", "Chocolate Bar", "Gummies", "Slushie", "Beverage Can", "Popcorn", "Hotdog" };

        for (int i = 0; i < orderSize; i++)
        {
            order.Add(items[Random.Range(0, items.Count)]);
        }
    }
}

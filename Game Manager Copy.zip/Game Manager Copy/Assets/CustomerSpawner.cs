using UnityEngine;

public class CustomerSpawner : MonoBehaviour
{
    public GameObject customerPrefab;
    public GameController gameController;
    public float customerSpawnDelay = 30f;

    private float timeSinceLastCustomer = 0f;

    public void SpawnNextCustomer()
    {
        // Wait before spawning next customer
        timeSinceLastCustomer = 0f;
        Instantiate(customerPrefab, transform.position, Quaternion.identity);
    }

    void Update()
    {
        if (gameController.customersServed < gameController.dailyCustomers)
        {
            timeSinceLastCustomer += Time.deltaTime;

            if (timeSinceLastCustomer >= customerSpawnDelay)
            {
                SpawnNextCustomer();
            }
        }
    }
}

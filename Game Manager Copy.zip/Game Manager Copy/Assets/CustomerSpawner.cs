using UnityEngine;

public class CustomerSpawner : MonoBehaviour
{
    public GameObject customerPrefab;
    public GameController gameController;
    public float customerSpawnDelay = 30f;

    private float timeSinceLastCustomer = 0f;

    void Start()
    {
        SpawnNextCustomer();
    }

    public void SpawnNextCustomer()
    {
        if (gameController.customersServed < gameController.dailyCustomers)
        {
            // Spawn at Point A
            timeSinceLastCustomer = 0f;
            GameObject customer = Instantiate(customerPrefab, transform.position, Quaternion.identity);

            // Get Customer script component
            Customer customerComponent = customer.GetComponent<Customer>();
            if (customerComponent != null)
            {
                customerComponent.MoveToPointB(); // Move to Point B
            }
        }
    }

    void Update()
    {
        if (gameController.customersServed < gameController.dailyCustomers)
        {
            timeSinceLastCustomer += Time.deltaTime;
            if (timeSinceLastCustomer >= customerSpawnDelay)
            {
                SpawnNextCustomer();
            }
        }
    }
}

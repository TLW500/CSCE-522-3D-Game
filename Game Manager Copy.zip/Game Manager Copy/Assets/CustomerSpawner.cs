using UnityEngine;
using System.Collections; // For IEnumerator

public class CustomerSpawner : MonoBehaviour
{
    public GameObject customerPrefab; 
    public GameController gameController;
    public float customerSpawnDelay = 10f;

    private float timeSinceLastCustomer = 0f;
    private float gameStartDelay = 3f; 
    private float timeSinceGameStart = 0f; 
    private GameObject currentCustomer; 

    void Start()
    {
    }

    public void StartSpawningCustomers()
{
    Debug.Log("Started customer spawning");
    StartCoroutine(SpawnCustomers());
}

private IEnumerator SpawnCustomers()
{
    while (gameController.customersServed < gameController.dailyCustomers && !gameController.isDayOver)
    {
        timeSinceLastCustomer += Time.deltaTime;
        if (timeSinceLastCustomer >= customerSpawnDelay && currentCustomer == null)
        {
            Debug.Log("Spawning next customer");
            SpawnNextCustomer(); 
        }
        yield return null; 
    }
}

public void SpawnNextCustomer()
{
    if (gameController.customersServed < gameController.dailyCustomers)
    {
        if (currentCustomer == null)
        {
            Debug.Log("Spawning new customer");
            currentCustomer = Instantiate(customerPrefab, new Vector3(-500f, 0f, 0f), Quaternion.identity);
            Customer customerComponent = currentCustomer.GetComponent<Customer>();
            if (customerComponent != null)
            {
                customerComponent.MoveToPointA(); 
            }
        }
    }
}
}
using UnityEngine;
using System.Collections.Generic;

public class Customer : MonoBehaviour
{
    public List<string> order;
    public Vector3 pointA;
    public Vector3 pointB;

    private float moveSpeed = 1.0f;
    private bool hasServed = false;

    void Start()
    {
        GenerateOrder();
        pointA = transform.position;
    }

    void Update()
    {
        if (!hasServed)
        {
            MoveToPointB();
        }
    }

    void GenerateOrder()
    {
        int orderSize = Random.Range(3, 6);
        order = new List<string>();

        List<string> items = new List<string>() { "Nougat Bar", "Chocolate Bar", "Gummies", "Slushie", "Beverage Can", "Popcorn", "Hotdog" };

        for (int i = 0; i < orderSize; i++)
        {
            order.Add(items[Random.Range(0, items.Count)]);
        }
    }

    void MoveToPointB()
    {
        float step = moveSpeed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, pointB, step);

        if (transform.position == pointB)
        {
            hasServed = true;
            StartCoroutine(StayAtPointB());
        }
    }

    System.Collections.IEnumerator StayAtPointB()
    {
        yield return new WaitForSeconds(10);
        MoveToPointA();
    }

    void MoveToPointA()
    {
        hasServed = false;
        pointB = pointA;
        float step = moveSpeed * Time.deltaTime;
        transform.position = Vector3.MoveTowards(transform.position, pointA, step);
    }
}

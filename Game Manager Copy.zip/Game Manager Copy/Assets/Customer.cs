using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using TMPro;

public class Customer : MonoBehaviour
{
    public GameController gameController;
    public List<string> order;
    public GameObject orderDisplay;

    private Vector3 pointA = new Vector3(0f, -0.55876f, 1.209f);
    private Vector3 pointB = new Vector3(1.5f, -0.5587637f, 1.209f);
    private Quaternion fixedRotation = Quaternion.Euler(-89.98f, 0f, 0f);

    private bool isMoving = false;
    private bool hasReturnedToA = false; // Track if customer has already reached Point A
    public float movementSpeed = 1.5f;

    void Start()
    {
        GenerateOrder();

        transform.position = pointA;
        transform.rotation = fixedRotation;

        if (orderDisplay != null)
        {
            CustomerOrderDisplay orderDisplayScript = orderDisplay.GetComponent<CustomerOrderDisplay>();
            if (orderDisplayScript != null)
            {
                Dictionary<string, float> itemPrices = new Dictionary<string, float>()
                {
                    { "Nougat Bar", 3f },
                    { "Chocolate Bar", 2f },
                    { "Gummies", 3f },
                    { "Slushie", 3f },
                    { "Beverage Can", 2f },
                    { "Popcorn", 4f },
                    { "Hotdog", 4f }
                };
                orderDisplayScript.DisplayOrder(order, orderDisplayScript.customerOrderText, itemPrices);
            }
        }

        MoveToPointB();
    }

    void GenerateOrder()
    {
        int orderSize = Random.Range(3, 6);
        order = new List<string>();

        List<string> items = new List<string>() { "Nougat Bar", "Chocolate Bar", "Gummies", "Slushie", "Beverage Can", "Popcorn", "Hotdog" };

        for (int i = 0; i < orderSize; i++)
        {
            order.Add(items[Random.Range(0, items.Count)]);
        }
    }

    public void MoveToPointB()
    {
        if (!isMoving)
        {
            StartCoroutine(MoveToPoint(pointB));  // Move the customer to Point B
        }
    }

    public void MoveToPointA()
    {
        if (!isMoving)
        {
            StartCoroutine(MoveToPoint(pointA)); // Move the customer to Point A
        }
    }

  public void Despawn()
    {
        transform.position = new Vector3(-50f, transform.position.y, transform.position.z);

        gameController.customerSpawner.SpawnNextCustomer(); 
    }

    private IEnumerator MoveToPoint(Vector3 target)
    {
        isMoving = true;
        Debug.Log("Moving to target: " + target); // Log when movement starts

        while (Vector3.Distance(transform.position, target) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, target, movementSpeed * Time.deltaTime);
            transform.rotation = fixedRotation;
            yield return null;
        }

        transform.position = target;
        transform.rotation = fixedRotation;
        isMoving = false;

        Debug.Log("Reached target: " + target); // Log when the target is reached

        if (target == pointB)
        {
            yield return new WaitForSeconds(5f); 
            CompleteOrder();
        }
        else if (target == pointA && hasReturnedToA)
        {
            Despawn(); 
            gameController.customerSpawner.SpawnNextCustomer();  
        }
        else if (target == pointA)
        {
            hasReturnedToA = true;
        }
    }


    public void CompleteOrder()
{
    GameController gameController = FindObjectOfType<GameController>();
    if (gameController != null)
    {
        gameController.ServeCustomer(this);
    }
}
}

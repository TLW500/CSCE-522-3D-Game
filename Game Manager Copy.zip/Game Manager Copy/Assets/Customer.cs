using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Customer : MonoBehaviour
{
    public List<string> order;
    public GameObject orderDisplay;

    private Vector3 pointB;

    void Start()
    {
        GenerateOrder();
        pointB = new Vector3(10, 0, 0);  // Replace with counter position
    }

    void GenerateOrder()
    {
        int orderSize = Random.Range(3, 6);
        order = new List<string>();

        List<string> items = new List<string>() { "Nougat Bar", "Chocolate Bar", "Gummies", "Slushie", "Beverage Can", "Popcorn", "Hotdog" };

        for (int i = 0; i < orderSize; i++)
        {
            order.Add(items[Random.Range(0, items.Count)]);
        }
    }

    public void MoveToPointB()
    {
        StartCoroutine(MoveToPoint(pointB));
    }

    public void MoveToPointA()
    {
        StartCoroutine(MoveToPoint(transform.position));
    }

    private IEnumerator MoveToPoint(Vector3 target)
    {
        float journeyTime = 10f;
        float startTime = Time.time;
        Vector3 startPosition = transform.position;

        while (Time.time - startTime < journeyTime)
        {
            transform.position = Vector3.Lerp(startPosition, target, (Time.time - startTime) / journeyTime);
            yield return null;
        }

        transform.position = target;
    }
}

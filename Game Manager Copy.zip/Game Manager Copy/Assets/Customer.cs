using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using TMPro;

public class Customer : MonoBehaviour
{
    public List<string> order;
    public GameObject orderDisplay;

    private Vector3 pointA = new Vector3(0f, -0.55876f, 1.209f);
    private Vector3 pointB = new Vector3(1.746f, -0.5587637f, 1.209f);
    private Vector3 despawnPosition = new Vector3(-10f, -0.55876f, 1.209f);
    private Quaternion fixedRotation = Quaternion.Euler(-89.98f, 0f, 0f);

    private bool isMoving = false;
    public float movementSpeed = 1f;

    void Start()
    {
        GenerateOrder();

        // Spawn customer at Point A
        transform.position = pointA;
        transform.rotation = fixedRotation;

        // Display the order
        if (orderDisplay != null)
        {
            CustomerOrderDisplay orderDisplayScript = orderDisplay.GetComponent<CustomerOrderDisplay>();
            if (orderDisplayScript != null)
            {
                Dictionary<string, float> itemPrices = new Dictionary<string, float>()
                {
                    { "Nougat Bar", 2.5f },
                    { "Chocolate Bar", 1.99f },
                    { "Gummies", 3.0f },
                    { "Slushie", 1.5f },
                    { "Beverage Can", 1.0f },
                    { "Popcorn", 2.0f },
                    { "Hotdog", 4.0f }
                };
                orderDisplayScript.DisplayOrder(order, orderDisplayScript.customerOrderText, itemPrices);
            }
        }

        // Start moving to Point B
        MoveToPointB();
    }

    void GenerateOrder()
    {
        int orderSize = Random.Range(3, 6);
        order = new List<string>();

        List<string> items = new List<string>() { "Nougat Bar", "Chocolate Bar", "Gummies", "Slushie", "Beverage Can", "Popcorn", "Hotdog" };

        for (int i = 0; i < orderSize; i++)
        {
            order.Add(items[Random.Range(0, items.Count)]);
        }
    }

    public void MoveToPointB()
    {
        if (!isMoving)
        {
            StartCoroutine(MoveToPoint(pointB));
        }
    }

    public void MoveToPointA()
    {
        if (!isMoving)
        {
            StartCoroutine(MoveToPoint(pointA));
        }
    }

    public void Despawn()
    {
        StartCoroutine(MoveToPoint(despawnPosition, true)); // Ensure the object is destroyed after reaching the despawn position
    }

    private IEnumerator MoveToPoint(Vector3 target, bool despawnAfter = false)
    {
        isMoving = true;

        while (Vector3.Distance(transform.position, target) > 0.1f) // Continue moving until close enough to target
        {
            transform.position = Vector3.MoveTowards(transform.position, target, movementSpeed * Time.deltaTime);
            transform.rotation = fixedRotation;
            yield return null;
        }

        transform.position = target;
        transform.rotation = fixedRotation;

        isMoving = false;

        if (despawnAfter)
        {
            Destroy(gameObject); // Destroy customer
        }
    }

    public void CompleteOrder()
    {
        GameController gameController = FindObjectOfType<GameController>();
        gameController.ServeCustomer(this);
    }
}

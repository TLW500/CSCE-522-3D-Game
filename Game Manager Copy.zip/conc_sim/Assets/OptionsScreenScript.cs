using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class OptionsScreenScript : MonoBehaviour
{
    public Toggle fullscreenTog;
    public List<ResItem> reses = new List<ResItem>();
    private int currentRes;
    public TMP_Text resLabel;

    public void ResLeft()
    {
        currentRes--;
        if (currentRes < 0)
            currentRes = 3;

        updateResLabel();
    }

    public void ResRight()
    {
        currentRes++;
        if (currentRes > reses.Count - 1)
            currentRes = 0;

        updateResLabel();
    }

    public void updateResLabel()
    {
        resLabel.text = reses[currentRes].width.ToString() + " x " + reses[currentRes].height.ToString();
    }

    public void ApplyGraphics()
    {
        Screen.SetResolution(reses[currentRes].width, reses[currentRes].height, true);
    }
}

[System.Serializable]
public class ResItem
{
    public int width, height;
}
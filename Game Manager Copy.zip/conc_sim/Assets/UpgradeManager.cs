using UnityEngine;

public class UpgradeManager : MonoBehaviour
{
    public int largerInventoryCost = 105;  
    public int additionalRestockCost = 75; 

    public int largerInventoryUpgradesPurchased = 0; 
    public int additionalRestocksPurchased = 0;      

    public int maxLargerInventoryUpgrades = 1;
    public int maxAdditionalRestocks = 3;

    public Inventory Inventory;
    public GameController GameController;

    public bool PurchaseUpgrade(string upgradeType, ref int playerMoney)
    {
        if (upgradeType == "LargerInventory" && playerMoney >= largerInventoryCost && largerInventoryUpgradesPurchased < maxLargerInventoryUpgrades)
        {
            playerMoney -= largerInventoryCost;
            Inventory.ApplyLargerInventoryUpgrade();  
            largerInventoryUpgradesPurchased++; 
            Inventory.ResetDailyStock(); 
            return true;
        }
        else if (upgradeType == "AdditionalRestock" && playerMoney >= additionalRestockCost && additionalRestocksPurchased < maxAdditionalRestocks)
        {
            playerMoney -= additionalRestockCost;
            additionalRestocksPurchased++;  
            return true;
        }

        return false;
    }

    public bool CanPurchaseUpgrade(string upgradeType)
    {
        if (upgradeType == "LargerInventory" && largerInventoryUpgradesPurchased < maxLargerInventoryUpgrades)
        {
            return true;
        }
        else if (upgradeType == "AdditionalRestock" && additionalRestocksPurchased < maxAdditionalRestocks)
        {
            return true;
        }

        return false; 
    }

    // Check if a specific upgrade reached max level
    public bool HasMaxUpgrade(string upgradeType)
    {
        if (upgradeType == "LargerInventory" && largerInventoryUpgradesPurchased >= maxLargerInventoryUpgrades)
        {
            return true;
        }
        else if (upgradeType == "AdditionalRestock" && additionalRestocksPurchased >= maxAdditionalRestocks)
        {
            return true;
        }

        return false; 
    }

    // Reset upgrades if necessary
    public void ResetUpgrades()
    {
        largerInventoryUpgradesPurchased = 0;
        additionalRestocksPurchased = 0;
    }
}

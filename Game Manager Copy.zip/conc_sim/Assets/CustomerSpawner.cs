using UnityEngine;
using System.Collections; // For IEnumerator

public class CustomerSpawner : MonoBehaviour
{
    public GameObject customerPrefab; 
    public GameController gameController;
    public float customerSpawnDelay = 10f;

    private float timeSinceLastCustomer = 0f;
    private GameObject currentCustomer; 

    void Start()
    {
    }

    public void StartSpawningCustomers()
{
    Debug.Log("Started customer spawning");
    StartCoroutine(SpawnCustomers());
}

private IEnumerator SpawnCustomers()
{
    while (gameController.customersServed < gameController.dailyCustomers && !gameController.isDayOver)
    {
        // Debugging spawning
        Debug.Log("Checking spawn loop... Customers served: " + gameController.customersServed);

        timeSinceLastCustomer += Time.deltaTime;
        if (timeSinceLastCustomer >= customerSpawnDelay && currentCustomer == null)
        {
            Debug.Log("Spawning customer... Time since last spawn: " + timeSinceLastCustomer);
            SpawnNextCustomer();
            timeSinceLastCustomer = 0f; // Reset spawn delay
        }
        yield return null;
    }
    Debug.Log("Customer spawning ended. Customers served: " + gameController.customersServed);
}


public void SpawnNextCustomer()
{
    if (gameController.customersServed < gameController.dailyCustomers)
    {
        if (currentCustomer == null)
        {
            Debug.Log("Spawning new customer");
            currentCustomer = Instantiate(customerPrefab, new Vector3(-500f, 0f, 0f), Quaternion.identity);
            Customer customerComponent = currentCustomer.GetComponent<Customer>();
            if (customerComponent != null)
            {
                customerComponent.MoveToPointA(); 
            }
        }
    }
}
}
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;

public class GameController : MonoBehaviour
{
    public int dayNumber = 1;
    public int dailyCustomers = 5;
    public int restockLimit = 3;
    public int money = 100;
    public int stockSizeCost = 105;
    public bool maxStockSizeReached = false;
    public int dailyRestocksCost = 75;
    public bool maxDailyRestocksReached = false;
    public int dailyRestocksLeft = 3;

    public TextMeshProUGUI dayText;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI customerOrderText;
    public TextMeshProUGUI messageText;

    public GameObject mainMenu;
    public GameObject pauseMenu;
    public GameObject gameOverMenu;
    public GameObject registerMenuPanel;

    public Inventory inventory;
    public CustomerSpawner customerSpawner;
    public UpgradeManager upgradeManager;
    public CustomerOrderDisplay customerOrderDisplay;
    public InventoryDisplay inventoryDisplay;

    public int customersServed;
    public int restocksUsed;
    public bool isDayOver;

    public Dropdown itemDropdown;
    public Button restockButton;
    public Button increaseStockSizeButton;
    public Button increaseRestocksButton;

    public bool isOrderBeingProcessed = false;

    void Start()
    {
        StartNewDay();
        InitializeRegisterMenu();
        inventory.ResetDailyStock();
        inventoryDisplay.RefreshInventory(inventory);
        money = 100;
        UpdateRegisterMenuButtons();
        gameOverMenu.SetActive(false);
        pauseMenu.SetActive(false);
        mainMenu.SetActive(true);
        registerMenuPanel.SetActive(false);
        Time.timeScale = 1f;
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
        messageText.text = "";
        customerSpawner.StartSpawningCustomers();
    }

    void Awake ()
    {
        DontDestroyOnLoad (this.gameObject);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (money <= 0 && !isDayOver)
        {
            GameOver();
        }
    }

    public void StartNewDay()
    {
        isDayOver = false;
        dayText.text = "Day: " + dayNumber;
        moneyText.text = "Money: $" + money;
        Debug.Log("Starting new day. Money: $" + money); // Debug log for starting new day
        customersServed = 0;
        restocksUsed = 0;
        inventory.ResetDailyStock();
        inventoryDisplay.RefreshInventory(inventory);
        customerSpawner.StartSpawningCustomers(); // Start spawning after 3 seconds
        inventoryDisplay.RefreshInventory(inventory);
    }

public void ServeCustomer(Customer customer)
{
    Debug.Log("Serving customer: " + customer.name); // Debug log to confirm the customer is being served
    if (isOrderBeingProcessed) return; // Prevent multiple orders from being processed at once

    customerOrderDisplay.DisplayOrder(customer.order, customerOrderText, inventory.prices);
    StartCoroutine(HandleCustomerOrder(customer));
}

private IEnumerator<WaitForSeconds> HandleCustomerOrder(Customer customer)
{
    isOrderBeingProcessed = true; // Set flag when the order starts
    Debug.Log("Processing order for customer: " + customer.name);

    int orderValue = inventory.ProcessOrder(customer.order);

    if (orderValue > 0)
    {
        Debug.Log("Order processed. Total value: $" + orderValue);
        money += orderValue;
        moneyText.text = "Money: $" + money.ToString("F2");
        inventoryDisplay.RefreshInventory(inventory);

        customer.MoveToPointB(); // Customer to Point B after the order is processed
        yield return new WaitForSeconds(2); 

        customersServed++;
        Debug.Log("Customers served: " + customersServed);

        customer.MoveToPointA(); // Return customer to Point A
        yield return new WaitForSeconds(2);

        customer.Despawn(); // Despawn after the order is completed
    }
    else
    {
        messageText.text = "One or more customer items are out of stock!";
        yield return new WaitForSeconds(2);
        messageText.text = "";
    }

    // Check ife day should end
    if (customersServed >= dailyCustomers)
    {
        Debug.Log("All customers served. Ending the day...");
        EndDay();
    }

    isOrderBeingProcessed = false; // Reset the flag after order is processed
}

    public void ToggleRegisterMenu()
    {
        registerMenuPanel.SetActive(!registerMenuPanel.activeSelf);
        Time.timeScale = registerMenuPanel.activeSelf ? 0 : 1;
    }

    void InitializeRegisterMenu()
    {
        increaseStockSizeButton.onClick.AddListener(() => PurchaseUpgrade("LargerInventory"));
        increaseRestocksButton.onClick.AddListener(() => PurchaseUpgrade("AdditionalRestock"));
        restockButton.onClick.AddListener(RestockSelectedItem);
        UpdateRegisterMenuButtons();
    }

    public void UpdateRegisterMenuButtons()
    {
        increaseStockSizeButton.interactable = money >= stockSizeCost && !upgradeManager.HasMaxUpgrade("LargerInventory");
        increaseRestocksButton.interactable = money >= dailyRestocksCost && !upgradeManager.HasMaxUpgrade("AdditionalRestock");
        restockButton.interactable = restocksUsed < restockLimit && dailyRestocksLeft > 0;
    }

    public void RestockSelectedItem()
    {
        string item = itemDropdown.options[itemDropdown.value].text;
        int quantity = 1;
        RestockItems(item, quantity);
    }

    public void RestockItems(string item, int quantity)
    {
        if (restocksUsed < restockLimit && inventory.RestockItem(item, quantity))
        {
            restocksUsed++;
            int previousMoney = money;
            money -= stockSizeCost;
            Debug.Log($"Money updated: ${previousMoney} -> ${money} (Spent ${stockSizeCost})"); // Debug log for money change
            moneyText.text = "Money: $" + money.ToString("F2");
            UpdateRegisterMenuButtons();
            inventoryDisplay.RefreshInventory(inventory);
        }
        else if (restocksUsed >= restockLimit && upgradeManager.additionalRestocksPurchased < upgradeManager.maxAdditionalRestocks)
        {
            if (restocksUsed < restockLimit + upgradeManager.additionalRestocksPurchased)
            {
                restocksUsed++;
                int previousMoney = money;
                money -= stockSizeCost;
                Debug.Log($"Money updated: ${previousMoney} -> ${money} (Spent ${stockSizeCost})"); // Debug log for money change
                moneyText.text = "Money: $" + money.ToString("F2");
                UpdateRegisterMenuButtons();
            }
        }
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        if (upgradeManager.PurchaseUpgrade(upgradeType, ref money))
        {
            Debug.Log($"Money after upgrade purchase: ${money}"); // Debug log for money after upgrade purchase
            moneyText.text = "Money: $" + money.ToString("F2");

            if (upgradeType == "LargerInventory")
            {
                restockLimit++;
                inventoryDisplay.RefreshInventory(inventory);
            }
            else if (upgradeType == "AdditionalRestock")
            {
                dailyRestocksLeft++;
            }

            UpdateRegisterMenuButtons();
        }
    }

    void EndDay()
    {
        isDayOver = true;
        int previousMoney = money;
        money -= 50;
        Debug.Log($"Money after end of day penalty: ${previousMoney} -> ${money} (Penalty: $50)"); // Debug log for money change
        if (money <= 0)
        {
            GameOver();
        }
        else
        {
            dayNumber++;
            StartNewDay();
        }
    }

    void GameOver()
    {
        gameOverMenu.SetActive(true);
    }

    void TogglePauseMenu()
    {
        pauseMenu.SetActive(!pauseMenu.activeSelf);
        Time.timeScale = pauseMenu.activeSelf ? 0 : 1;
    }
}

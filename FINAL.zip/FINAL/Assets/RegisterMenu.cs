using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RegisterMenu : MonoBehaviour
{
    public GameObject registerMenuPanel;
    public GameController GameController;
    public Inventory inventory;
    public TMP_Dropdown itemDropdown;
    public Button restockButton;
    public Button stockSizeButton;
    public Button dailyRestocksButton;
    public Button resumeButton;
    public TextMeshProUGUI feedbackText;
    public TextMeshProUGUI moneyText;
    public void RefreshUpgradeText()
    {
        GameController.UpdateUpgradeTexts();
    }

    private bool isMenuOpen = false;
    
   public void UpdateUpgradeTexts()
    {
        GameController.UpdateUpgradeTexts();
    }
void PopulateDropdown()
{
    GameController.PopulateItemDropdown();  // Call the GameController to populate the dropdown
}

    void Start()
    {
        registerMenuPanel.SetActive(false);
        PopulateDropdown();

        restockButton.onClick.AddListener(RestockItem);
        stockSizeButton.onClick.AddListener(IncreaseStockSize);
        dailyRestocksButton.onClick.AddListener(IncreaseDailyRestocks);
        resumeButton.onClick.AddListener(ResumeGame);

        UpdateButtonStates();
        UpdateUpgradeTexts();
    }
    

    void ToggleRegisterMenu()
    {
        isMenuOpen = !isMenuOpen;
        registerMenuPanel.SetActive(isMenuOpen);

        if (isMenuOpen)
        {
            Time.timeScale = 0;
            PopulateDropdown();
            UpdateUpgradeTexts();
        }
        else
        {
            Time.timeScale = 1;
        }

        UpdateButtonStates();
    }

    void ResumeGame()
    {
        ToggleRegisterMenu();
    }

    void RestockItem()
    {
        string selectedItem = itemDropdown.options[itemDropdown.value].text;

        if (selectedItem == "No items to restock")
        {
            feedbackText.text = "No items available for restocking!";
            return;
        }

        if (GameController.dailyRestocksLeft <= 0)
        {
            feedbackText.text = "No daily restocks left!";
            return;
        }
        if (inventory.stock[selectedItem] >= inventory.maxStock[selectedItem])
        {
            feedbackText.text = selectedItem + " is already at max stock!";
            return;
        }

        if (inventory.RestockItem(selectedItem, 1))
        {
            PopulateDropdown(); 
            UpdateUpgradeTexts(); 
            UpdateButtonStates();
            feedbackText.text = selectedItem + " restocked!";
        }
        else
        {
            feedbackText.text = "Restock failed for " + selectedItem + " (unknown error).";
        }
    }

    void IncreaseStockSize()
    {
        if (GameController.money >= GameController.stockSizeCost)
        {
            GameController.PurchaseUpgrade("LargerInventory");
            feedbackText.text = "Stock size upgraded!";
            PopulateDropdown();
            UpdateButtonStates();
        }
        else
        {
            feedbackText.text = "Not enough money!";
        }
    }

    void IncreaseDailyRestocks()
    {
        if (GameController.money >= GameController.dailyRestocksCost)
        {
            GameController.PurchaseUpgrade("AdditionalRestock");
            feedbackText.text = "Daily restocks upgraded!";
            UpdateButtonStates();
            UpdateUpgradeTexts(); 
            PopulateDropdown(); 
        }
        else
        {
            feedbackText.text = "Not enough money!";
        }
    }
    public void UpdateButtonStates()
    {
        restockButton.interactable = itemDropdown.options.Count > 0 && itemDropdown.value > 0 && GameController.dailyRestocksLeft > 0;

        stockSizeButton.interactable = GameController.money >= GameController.stockSizeCost;  // No max check
        dailyRestocksButton.interactable = GameController.money >= GameController.dailyRestocksCost;  // No max check

        moneyText.text = "Money: $" + GameController.money;
    }
}
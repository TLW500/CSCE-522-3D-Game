using UnityEngine;

public class MoveCanvasToCamera : MonoBehaviour
{
    public Camera mainCamera;  // Reference to the camera
    public float distanceFromCamera = 5f;  // How far from the camera you want the canvas
    public float offsetX = 2f;  // Horizontal offset (move to the right)

    void Start()
    {
        // Ensure the canvas is in world space
        Canvas canvas = GetComponent<Canvas>();
        if (canvas.renderMode != RenderMode.WorldSpace)
        {
            canvas.renderMode = RenderMode.WorldSpace;
        }

        // Set the canvas name to "CanvasFront"
        gameObject.name = "CanvasFront";

        // Position the canvas in front of the camera, slightly to the right
        PositionCanvas();
    }

    void PositionCanvas()
    {
        // Position the canvas in front of the camera
        Vector3 positionInFrontOfCamera = mainCamera.transform.position + mainCamera.transform.forward * distanceFromCamera;

        // Add an offset to move the canvas to the right
        positionInFrontOfCamera += mainCamera.transform.right * offsetX;

        // Set the position of the canvas
        transform.position = positionInFrontOfCamera;

        // Optionally, align the canvas to face the camera
        transform.LookAt(mainCamera.transform);
        transform.rotation = Quaternion.Euler(0, transform.rotation.eulerAngles.y, 0);  // Keep upright
    }
}

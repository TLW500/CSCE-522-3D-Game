using UnityEngine;

public class RegisterObject : MonoBehaviour
{
    public GameObject registerMenu;
    public GameController GameController;
    public Inventory inventory;

    void Start()
    {
        // Ensure hidden
        registerMenu.SetActive(false);
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // Left click
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider != null && hit.collider.gameObject == this.gameObject)
                {
                    ToggleRegisterMenu(); // Show/hide
                }
            }
        }
    }

    // Toggle the visibility 
    void ToggleRegisterMenu()
    {
        bool isActive = registerMenu.activeSelf;
        registerMenu.SetActive(!isActive);
        if (registerMenu.activeSelf)
        {
            Time.timeScale = 0; // Pause the game 
        }
        else
        {
            Time.timeScale = 1; // Resume the game
        }
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        if (upgradeType == "StockSize" && GameController.money >= GameController.stockSizeCost && 
            !GameController.maxStockSizeReached) 
        {
            GameController.PurchaseUpgrade("StockSize");
        }
        else if (upgradeType == "DailyRestocks" && GameController.money >= GameController.dailyRestocksCost && 
                 !GameController.maxDailyRestocksReached) 
        {
            GameController.PurchaseUpgrade("DailyRestocks");
        }
    }

  public void RestockItem(string item, int quantity)
{
    if (GameController.dailyRestocksLeft > 0)
    {
        GameController.RestockItems(item, quantity);
        GameController.dailyRestocksLeft--;  
    }
}
}

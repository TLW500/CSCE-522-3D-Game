using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class Inventory : MonoBehaviour
{
    public Dictionary<string, int> stock = new Dictionary<string, int>()
    {
        {"Nougat Bar", 5},
        {"Chocolate Bar", 5},
        {"Gummies", 5},
        {"Slushie", 5},
        {"Beverage Can", 12},
        {"Popcorn", 5},
        {"Hotdog", 10}
    };

    public Dictionary<string, float> prices = new Dictionary<string, float>()
            {
                    { "Nougat Bar", 2f },
                    { "Chocolate Bar", 2f },
                    { "Gummies", 2f },
                    { "Slushie", 3f },
                    { "Beverage Can", 2f },
                    { "Popcorn", 4f },
                    { "Hotdog", 4f }
                };

    public Dictionary<string, int> maxStock = new Dictionary<string, int>()
    {
        {"Nougat Bar", 10},
        {"Chocolate Bar", 10},
        {"Gummies", 10},
        {"Slushie", 10},
        {"Beverage Can", 12},
        {"Popcorn", 10},
        {"Hotdog", 10}
    };

    public int additionalRestockLimit = 0;

    public void ResetDailyStock()
    {
        List<string> keys = new List<string>(stock.Keys);

        foreach (string key in keys)
        {
            stock[key] = maxStock[key];
        }
    }

    public int ProcessOrder(List<string> order)
    {
        int totalValue = 0;

        Dictionary<string, int> tempStock = new Dictionary<string, int>(stock);

        foreach (string item in order)
        {
            if (tempStock.ContainsKey(item) && tempStock[item] > 0)
            {
                tempStock[item]--;
                totalValue += Mathf.RoundToInt(prices[item]);
            }
            else
            {
                return 0;  
            }
        }

        stock = tempStock;
        return totalValue;
    }


    public bool RestockItem(string item, int quantity)
    {
        if (stock.ContainsKey(item) && stock[item] + quantity <= maxStock[item])
        {
            stock[item] += quantity;
            return true;
        }

        return false;
    }

    public void ApplyLargerInventoryUpgrade()
    {
        foreach (var item in stock.Keys.ToList())
        {
            stock[item] = Mathf.Min(stock[item] + 2, maxStock[item]);
        }
    }

    public void ApplyAdditionalRestockUpgrade()
    {
        additionalRestockLimit++;
    }

}


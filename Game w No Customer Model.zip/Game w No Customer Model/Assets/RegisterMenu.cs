using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RegisterMenu : MonoBehaviour
{
    public GameObject registerMenuPanel;
    public GameController GameController;
    public Inventory inventory;
    public TMP_Dropdown itemDropdown;
    public Button restockButton;
    public Button stockSizeButton;
    public Button dailyRestocksButton;
    public Button resumeButton;
    public TextMeshProUGUI feedbackText;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI secondaryMoneyText;
    public TextMeshProUGUI dailyRestocksRemainingText;
    public TextMeshProUGUI stockSizeUpgradesRemainingText;
    public TextMeshProUGUI dailyRestockLimitUpgradesRemainingText;

    private bool isMenuOpen = false;

    void Start()
    {
        registerMenuPanel.SetActive(false);
        PopulateDropdown();

        restockButton.onClick.AddListener(RestockItem);
        stockSizeButton.onClick.AddListener(IncreaseStockSize);
        dailyRestocksButton.onClick.AddListener(IncreaseDailyRestocks);
        resumeButton.onClick.AddListener(ResumeGame);

        UpdateButtonStates();
        GameController.UpdateUpgradeTexts();
    }

    void ToggleRegisterMenu()
    {
        isMenuOpen = !isMenuOpen;
        registerMenuPanel.SetActive(isMenuOpen);

        if (isMenuOpen)
        {
            Time.timeScale = 0;
            PopulateDropdown();
            GameController.UpdateUpgradeTexts();
        }
        else
        {
            Time.timeScale = 1;
        }

        UpdateButtonStates();
    }

    void ResumeGame()
    {
        ToggleRegisterMenu();
    }

    void PopulateDropdown()
    {
        itemDropdown.options.Clear();

        bool hasRestockableItems = false;

        foreach (var item in inventory.stock.Keys)
        {
            if (inventory.stock[item] < inventory.maxStock[item])
            {
                itemDropdown.options.Add(new TMP_Dropdown.OptionData(item));
                hasRestockableItems = true;
            }
        }

        if (!hasRestockableItems)
        {
            itemDropdown.options.Add(new TMP_Dropdown.OptionData("No items to restock"));
            itemDropdown.interactable = false;
            restockButton.interactable = false;
        }
        else
        {
            itemDropdown.interactable = true;
            restockButton.interactable = true;
        }

        itemDropdown.RefreshShownValue();
    }

    void RestockItem()
    {
        string selectedItem = itemDropdown.options[itemDropdown.value].text;

        if (selectedItem == "No items to restock")
        {
            feedbackText.text = "No items available for restocking!";
            return;
        }

        if (GameController.dailyRestocksLeft > 0)
        {
            if (inventory.stock[selectedItem] < inventory.maxStock[selectedItem])
            {
                GameController.RestockItems(selectedItem, 1);
                PopulateDropdown();
                UpdateButtonStates();
                feedbackText.text = selectedItem + " restocked!";
            }
            else
            {
                feedbackText.text = "Item is already at max stock!";
            }
        }
        else
        {
            feedbackText.text = "No daily restocks left!";
        }
    }

    void IncreaseStockSize()
    {
        if (GameController.money >= GameController.stockSizeCost && !GameController.maxStockSizeReached)
        {
            GameController.PurchaseUpgrade("LargerInventory");
            feedbackText.text = "Stock size upgraded!";
            PopulateDropdown();
            UpdateButtonStates();
        }
        else
        {
            feedbackText.text = "Not enough money or max upgrades reached!";
        }
    }

    void IncreaseDailyRestocks()
    {
        if (GameController.money >= GameController.dailyRestocksCost && !GameController.maxDailyRestocksReached)
        {
            GameController.PurchaseUpgrade("AdditionalRestock");
            feedbackText.text = "Daily restocks upgraded!";
            UpdateButtonStates();
        }
        else
        {
            feedbackText.text = "Not enough money or max daily restocks reached!";
        }
    }

    void UpdateButtonStates()
    {
        stockSizeButton.interactable = GameController.money >= GameController.stockSizeCost && !GameController.maxStockSizeReached;
        dailyRestocksButton.interactable = GameController.money >= GameController.dailyRestocksCost && !GameController.maxDailyRestocksReached;
        restockButton.interactable = GameController.dailyRestocksLeft > 0 && itemDropdown.options.Count > 0;

        moneyText.text = "Money: $" + GameController.money;
        secondaryMoneyText.text = "Money: $" + GameController.money;

        if (GameController.maxStockSizeReached)
            stockSizeButton.interactable = false;

        if (GameController.maxDailyRestocksReached)
            dailyRestocksButton.interactable = false;
    }

    void UpdateUpgradeTexts()
    {
        dailyRestocksRemainingText.text = "Daily Restocks Remaining: " + GameController.dailyRestocksLeft;
        stockSizeUpgradesRemainingText.text = "Stock Size Upgrades Remaining: " + (GameController.maxStockSizeReached ? "Max Reached" : "Available");
        dailyRestockLimitUpgradesRemainingText.text = "Daily Restock Limit Upgrades Remaining: " + (GameController.maxDailyRestocksReached ? "Max Reached" : "Available");
    }
}

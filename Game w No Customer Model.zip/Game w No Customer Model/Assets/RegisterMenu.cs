using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RegisterMenu : MonoBehaviour
{
    public GameObject registerMenuPanel;
    public GameController GameController;
    public Inventory inventory;
    public Dropdown itemDropdown;
    public Button restockButton;
    public Button stockSizeButton;
    public Button dailyRestocksButton;
    public Button resumeButton;
    public TextMeshProUGUI feedbackText;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI dailyRestocksRemainingText;
    public TextMeshProUGUI stockSizeUpgradesRemainingText;
    public TextMeshProUGUI dailyRestockLimitUpgradesRemainingText;

    private bool isMenuOpen = false;

    void Start()
    {
        registerMenuPanel.SetActive(false);
        itemDropdown.options.Clear();
        foreach (var item in inventory.stock.Keys)
        {
            if (inventory.stock[item] < inventory.maxStock[item])
            {
                itemDropdown.options.Add(new Dropdown.OptionData(item));
            }
        }

        restockButton.onClick.AddListener(RestockItem);
        stockSizeButton.onClick.AddListener(IncreaseStockSize);
        dailyRestocksButton.onClick.AddListener(IncreaseDailyRestocks);
        resumeButton.onClick.AddListener(ResumeGame);

        UpdateButtonStates();
        GameController.UpdateUpgradeTexts();  // Update text from the GameController
    }

    void OnMouseDown()
    {
        if (GameController.money > 0)
        {
            ToggleRegisterMenu();
        }
    }

    void ToggleRegisterMenu()
    {
        isMenuOpen = !isMenuOpen;
        registerMenuPanel.SetActive(isMenuOpen);

        if (isMenuOpen)
        {
            Time.timeScale = 0;
            GameController.UpdateUpgradeTexts(); // Update text from the GameController
        }
        else
        {
            Time.timeScale = 1;
        }

        UpdateButtonStates();
    }

    void IncreaseStockSize()
    {
        if (GameController.money >= GameController.stockSizeCost && !GameController.maxStockSizeReached)
        {
            GameController.PurchaseUpgrade("StockSize");
            UpdateButtonStates();
            UpdateUpgradeTexts();
        }
        else
        {
            feedbackText.text = "Not enough money or max upgrades reached!";
        }
    }

    void IncreaseDailyRestocks()
    {
        if (GameController.money >= GameController.dailyRestocksCost && !GameController.maxDailyRestocksReached)
        {
            GameController.PurchaseUpgrade("DailyRestocks");
            UpdateButtonStates();
            UpdateUpgradeTexts();
        }
        else
        {
            feedbackText.text = "Not enough money or max daily restocks reached!";
        }
    }

    void RestockItem()
    {
        string selectedItem = itemDropdown.options[itemDropdown.value].text;

        if (GameController.dailyRestocksLeft > 0)
        {
            if (inventory.stock[selectedItem] < inventory.maxStock[selectedItem])
            {
                GameController.RestockItems(selectedItem, 1);
                UpdateButtonStates();
                feedbackText.text = selectedItem + " restocked!";
            }
            else
            {
                feedbackText.text = "Item is already at max stock!";
            }
        }
        else
        {
            feedbackText.text = "No daily restocks left!";
        }
    }

    void ResumeGame()
    {
        ToggleRegisterMenu();
    }

    void UpdateButtonStates()
    {
        stockSizeButton.interactable = GameController.money >= GameController.stockSizeCost && !GameController.maxStockSizeReached;
        dailyRestocksButton.interactable = GameController.money >= GameController.dailyRestocksCost && !GameController.maxDailyRestocksReached;
        restockButton.interactable = GameController.dailyRestocksLeft > 0;

        moneyText.text = "Money: $" + GameController.money;

        if (GameController.maxStockSizeReached)
            stockSizeButton.interactable = false;

        if (GameController.maxDailyRestocksReached)
            dailyRestocksButton.interactable = false;
    }

    void UpdateUpgradeTexts()
    {
        // Ensure the texts are updated when the menu is opened
        Debug.Log("Updating upgrade texts...");
        dailyRestocksRemainingText.text = "Daily Restocks Remaining: " + GameController.dailyRestocksLeft;
        stockSizeUpgradesRemainingText.text = "Stock Size Upgrades Remaining: " + (GameController.maxStockSizeReached ? "Max Reached" : "Available");
        dailyRestockLimitUpgradesRemainingText.text = "Daily Restock Limit Upgrades Remaining: " + (GameController.maxDailyRestocksReached ? "Max Reached" : "Available");
    }
}

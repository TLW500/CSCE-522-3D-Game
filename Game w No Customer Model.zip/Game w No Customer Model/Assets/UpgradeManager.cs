using UnityEngine;

public class UpgradeManager : MonoBehaviour
{
    public int largerInventoryCost = 105;  
    public int additionalRestockCost = 75; 

    public int largerInventoryUpgradesPurchased = 0; 
    public int additionalRestocksPurchased = 0;      

    public Inventory Inventory;
    public GameController gameController;
    public RegisterMenu registerMenu;

public bool PurchaseUpgrade(string upgradeType, ref int playerMoney)
{
    if (upgradeType == "LargerInventory" && playerMoney >= largerInventoryCost)
    {
        playerMoney -= largerInventoryCost;
        Inventory.ApplyLargerInventoryUpgrade();  
        largerInventoryUpgradesPurchased++; 
        Inventory.ResetDailyStock(); 
        return true;
    }
    else if (upgradeType == "AdditionalRestock" && playerMoney >= additionalRestockCost)
    {
        playerMoney -= additionalRestockCost;
        gameController.dailyRestocksLeft++;  
        registerMenu.UpdateUpgradeTexts(); 
        additionalRestocksPurchased++;  
        return true;
    }

    return false;
}

    public bool CanPurchaseUpgrade(string upgradeType)
    {
        if (upgradeType == "LargerInventory")
        {
            return true; 
        }
        else if (upgradeType == "AdditionalRestock")
        {
            return true; 
        }

        return false; 
    }

    public void ResetUpgrades()
    {
        largerInventoryUpgradesPurchased = 0;
        additionalRestocksPurchased = 0;
    }
}

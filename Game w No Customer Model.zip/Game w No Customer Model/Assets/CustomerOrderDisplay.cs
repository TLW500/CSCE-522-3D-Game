using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class CustomerOrderDisplay : MonoBehaviour
{
    public TextMeshProUGUI customerOrderText;

    public void DisplayOrder(List<string> order, TextMeshProUGUI orderTextUI, Dictionary<string, float> itemPrices)
    {
        string orderDetails = "";
        float totalPrice = 0f;

        foreach (string item in order)
        {
            if (itemPrices.ContainsKey(item))
            {
                float price = itemPrices[item];
                orderDetails += item + " - $" + price.ToString("F2") + "\n";  
                totalPrice += price;
            }
            else
            {
                orderDetails += item + " - Price not available\n";
            }
        }

        orderDetails += "\nTotal: $" + totalPrice.ToString("F2");

        customerOrderText.text = orderDetails;
    }

    public void ClearOrder()
    {
        customerOrderText.text = "";
    }
}

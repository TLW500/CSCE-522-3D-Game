using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections; 

public class MainMenuController : MonoBehaviour
{
    public CanvasGroup OptionPanel; 

    public void PlayGame()
    {
        SceneManager.LoadScene("SampleScene");
        StartCoroutine(InitializeGameController());
    }

    private IEnumerator InitializeGameController()
    {
        yield return new WaitForEndOfFrame(); 

        if (GameController.Instance != null)
        {
            GameController.Instance.StartNewDay(); 
        }
    }


    public void Option()
    {
        if (OptionPanel != null)
        {
            bool isActive = OptionPanel.alpha > 0;
            OptionPanel.alpha = isActive ? 0 : 1;
            OptionPanel.interactable = !isActive;
            OptionPanel.blocksRaycasts = !isActive;
        }
    }

    public void QuitGame()
    {
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
        #else
        Application.Quit();
        #endif
    }
}

using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using TMPro;

public class GameController : MonoBehaviour
{
    public static GameController Instance;

    public int dayNumber = 1;
    public int dailyCustomers = 5;
    public int restockLimit = 3;
    public int money = 100;
    public int stockSizeCost = 105;
    public bool maxStockSizeReached = false;
    public int dailyRestocksCost = 75;
    public bool maxDailyRestocksReached = false;
    public int dailyRestocksLeft = 3;

    public TextMeshProUGUI dayText;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI customerOrderText;
    public TextMeshProUGUI messageText;
    public TextMeshProUGUI messageTwoText;

    public GameObject pauseMenu;
    public GameObject gameOverMenu;
    public GameObject registerMenuPanel;

    public Inventory inventory;
    public UpgradeManager upgradeManager;
    public CustomerOrderDisplay customerOrderDisplay;
    public InventoryDisplay inventoryDisplay;

    public int customersServed;
    public int restocksUsed;
    public bool isDayOver;

    public TMP_Dropdown itemDropdown;
    public Button restockButton;
    public Button increaseStockSizeButton;
    public Button increaseRestocksButton;
    public TextMeshProUGUI currentCustomerText;

    public TextMeshProUGUI dailyRestocksRemainingText;

    public bool isOrderBeingProcessed = false;

    private int currentCustomerNumber = 0;
    private List<List<string>> customerOrders = new List<List<string>>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        EventSystem[] eventSystems = FindObjectsOfType<EventSystem>();
        if (eventSystems.Length > 1)
        {
            for (int i = 1; i < eventSystems.Length; i++)
            {
                Destroy(eventSystems[i].gameObject);
            }
        }
        
        if (Instance != this) return;

        StartNewDay();
        InitializeRegisterMenu();
        inventory.ResetDailyStock();
        inventoryDisplay.RefreshInventory(inventory);
        money = 100;
        UpdateRegisterMenuButtons();
        gameOverMenu.SetActive(false);
        pauseMenu.SetActive(false);
        registerMenuPanel.SetActive(false);
        Time.timeScale = 1f;
        dailyRestocksLeft = 3;
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
        messageText.text = "";
        messageTwoText.text = "";
        PopulateItemDropdown();  
        StartCoroutine(SpawnCustomers());
    }
    
    public void UpdateUpgradeTexts()
    {
        dailyRestocksRemainingText.text = "Daily Restocks Remaining: " + dailyRestocksLeft.ToString();
    }

    void TogglePauseMenu()
    {
        pauseMenu.SetActive(!pauseMenu.activeSelf);
        Time.timeScale = pauseMenu.activeSelf ? 0 : 1;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (money <= 0 && !isDayOver)
        {
            GameOver();
        }
    }

    public void StartNewDay()
    {
        isDayOver = false;
        dayText.text = "Day: " + dayNumber;
        moneyText.text = "Money: $" + money;
        customersServed = 0;
        restocksUsed = 0;
        inventory.ResetDailyStock();
        inventoryDisplay.RefreshInventory(inventory);
        dailyRestocksLeft = 3;
        currentCustomerNumber = 0;
        customerOrders.Clear();
        StartCoroutine(DelayBeforeCustomerSpawn());
    }

    private IEnumerator DelayBeforeCustomerSpawn()
    {
        yield return new WaitForSeconds(4f);
        StartCoroutine(SpawnCustomers());
    }

    public void ServeCustomer(List<string> order)
    {
        if (isOrderBeingProcessed)
        {
            return;
        }

        customerOrderDisplay.DisplayOrder(order, customerOrderText, inventory.prices);
        StartCoroutine(HandleCustomerOrder(order));
    }

    private IEnumerator HandleCustomerOrder(List<string> customerOrder)
    {
        isOrderBeingProcessed = true;

        yield return new WaitForSeconds(5f);
        int orderValue = inventory.ProcessOrder(customerOrder);

        if (orderValue > 0)
        {
            money += orderValue;
            moneyText.text = "Money: $" + money.ToString("F2");
            inventoryDisplay.RefreshInventory(inventory);
            PopulateItemDropdown();

            yield return new WaitForSeconds(2);
            customersServed++;
        }
        else
        {
            messageText.text = "One or more customer items are out of stock!";
            yield return new WaitForSeconds(2);
            messageText.text = "";
        }

        if (customersServed >= dailyCustomers)
        {
            EndDay();
        }

        isOrderBeingProcessed = false;
    }

    private IEnumerator SpawnCustomers()
    {
        while (!isDayOver && currentCustomerNumber < dailyCustomers)
        {
            currentCustomerNumber++;

            currentCustomerText.text = "Current Customer: " + currentCustomerNumber;
            currentCustomerText.gameObject.SetActive(true);

            List<string> order = GenerateOrder();
            customerOrders.Add(order);

            messageTwoText.text = "Customer " + currentCustomerNumber + " enters!";
            yield return new WaitForSeconds(2f);
            messageTwoText.text = "";

            ServeCustomer(order);

            yield return new WaitForSeconds(10f);

            messageTwoText.text = "Customer " + currentCustomerNumber + " leaves!";
            yield return new WaitForSeconds(2f);
            messageTwoText.text = "";

            customerOrderDisplay.ClearOrder();
            currentCustomerText.gameObject.SetActive(false);

            yield return new WaitForSeconds(4f);
        }
        currentCustomerText.gameObject.SetActive(false);
    }

    private List<string> GenerateOrder()
    {
        int orderSize = Random.Range(3, 6);
        List<string> order = new List<string>();

        List<string> items = new List<string>() { "Nougat Bar", "Chocolate Bar", "Gummies", "Slushie", "Beverage Can", "Popcorn", "Hotdog" };

        for (int i = 0; i < orderSize; i++)
        {
            string item = items[Random.Range(0, items.Count)];
            order.Add(item);
        }

        return order;
    }

    public void ToggleRegisterMenu()
    {
        registerMenuPanel.SetActive(!registerMenuPanel.activeSelf);
        Time.timeScale = registerMenuPanel.activeSelf ? 0 : 1;
    }

    void InitializeRegisterMenu()
    {
        increaseStockSizeButton.onClick.AddListener(() => PurchaseUpgrade("LargerInventory"));
        increaseRestocksButton.onClick.AddListener(() => PurchaseUpgrade("AdditionalRestock"));
        restockButton.onClick.AddListener(RestockSelectedItem);
        UpdateRegisterMenuButtons();
    }

    public void UpdateRegisterMenuButtons()
    {
        increaseStockSizeButton.interactable = money >= stockSizeCost && !maxStockSizeReached;
        increaseRestocksButton.interactable = money >= dailyRestocksCost && !maxDailyRestocksReached;
        restockButton.interactable = restocksUsed < restockLimit && dailyRestocksLeft > 0;
    }

    public void RestockSelectedItem()
    {
        string item = itemDropdown.options[itemDropdown.value].text;
        int quantity = 1;

        if (RestockItems(item, quantity))
        {
            PopulateItemDropdown();
        }
    }

    public bool RestockItems(string item, int quantity)
    {
        if (restocksUsed < restockLimit && dailyRestocksLeft > 0 && inventory.RestockItem(item, quantity))
        {
            restocksUsed++;
            moneyText.text = "Money: $" + money.ToString("F2");
            UpdateRegisterMenuButtons();
            inventoryDisplay.RefreshInventory(inventory);
            UpdateUpgradeTexts();

            Debug.Log("Restocked " + item + ". dailyRestocksLeft updated to: " + dailyRestocksLeft);

            return true;
        }

        return false;
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        upgradeManager.PurchaseUpgrade(upgradeType, ref money);

        if (money >= 0)
        {
            moneyText.text = "Money: $" + money.ToString("F2");

            if (upgradeType == "LargerInventory")
            {
                restockLimit++;
                inventoryDisplay.RefreshInventory(inventory);
            }
            else if (upgradeType == "AdditionalRestock")
            {
                if (dailyRestocksLeft < 3)
                {
                    dailyRestocksLeft++;
                    Debug.Log("Purchased Additional Restock. dailyRestocksLeft updated to: " + dailyRestocksLeft);
                }
                else
                {
                    restockLimit++;
                    Debug.Log("Purchased Additional Restock. Base restock limit updated to: " + restockLimit);
                }
            }

            UpdateRegisterMenuButtons();
        }
        else
        {
            messageText.text = "Not enough money!";
        }
    }

    public void PopulateItemDropdown()
    {
        itemDropdown.options.Clear();
        bool hasRestockableItems = false;

        foreach (var item in inventory.stock.Keys)
        {
            if (inventory.stock[item] < inventory.maxStock[item])
            {
                itemDropdown.options.Add(new TMP_Dropdown.OptionData(item));
                hasRestockableItems = true;
            }
        }

        if (!hasRestockableItems)
        {
            itemDropdown.options.Add(new TMP_Dropdown.OptionData("No items to restock"));
            itemDropdown.interactable = false;
            restockButton.interactable = false;
        }
        else
        {
            itemDropdown.interactable = true;
            restockButton.interactable = true;
        }

        itemDropdown.RefreshShownValue();

        Debug.Log("Dropdown populated with options:");
        foreach (var option in itemDropdown.options)
        {
            Debug.Log("Item: " + option.text);
        }
    }

    public void UpdateMoneyText()
    {
        moneyText.text = "Money: $" + money.ToString("F2");
    }

    void EndDay()
    {
        isDayOver = true;
        money -= 50;
        if (money <= 0)
        {
            GameOver();
        }
        else
        {
            dayNumber++;
            StartNewDay();
        }
    }

    void GameOver()
    {
        gameOverMenu.SetActive(true);
    }
}

using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic; 
using TMPro;

public class GameController : MonoBehaviour
{
    public int dayNumber = 1;
    public int dailyCustomers = 5;
    public int restockLimit = 3;
    public int money = 100;
    public int stockSizeCost = 105;
    public bool maxStockSizeReached = false;
    public int dailyRestocksCost = 75;
    public bool maxDailyRestocksReached = false;
    public int dailyRestocksLeft = 3;

    public TextMeshProUGUI dayText;
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI customerOrderText;
    public TextMeshProUGUI messageText;
    public TextMeshProUGUI messageTwoText;  // Added reference for customer enter/leave messages

    public GameObject mainMenu;
    public GameObject pauseMenu;
    public GameObject gameOverMenu;
    public GameObject registerMenuPanel;

    public Inventory inventory;
    public UpgradeManager upgradeManager;
    public CustomerOrderDisplay customerOrderDisplay;
    public InventoryDisplay inventoryDisplay;

    public int customersServed;
    public int restocksUsed;
    public bool isDayOver;

    public Dropdown itemDropdown;
    public Button restockButton;
    public Button increaseStockSizeButton;
    public Button increaseRestocksButton;
    public TextMeshProUGUI currentCustomerText; 

    public TextMeshProUGUI dailyRestocksRemainingText;
    public TextMeshProUGUI stockSizeUpgradesRemainingText;
    public TextMeshProUGUI dailyRestockLimitUpgradesRemainingText; 

    public bool isOrderBeingProcessed = false;

    private int currentCustomerNumber = 0;  // Track the current customer number for the day
    private List<List<string>> customerOrders = new List<List<string>>();  // List to store customer orders

    void Start()
    {
        StartNewDay();
        InitializeRegisterMenu();
        inventory.ResetDailyStock();
        inventoryDisplay.RefreshInventory(inventory);
        money = 100;
        UpdateRegisterMenuButtons();
        gameOverMenu.SetActive(false);
        pauseMenu.SetActive(false);
        mainMenu.SetActive(true);
        registerMenuPanel.SetActive(false);
        Time.timeScale = 1f;
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
        messageText.text = "";
        messageTwoText.text = "";  // Initialize the messageText
        StartCoroutine(SpawnCustomers());  // Start customer spawning coroutine
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (money <= 0 && !isDayOver)
        {
            GameOver();
        }
    }

    public void StartNewDay()
    {
        isDayOver = false;
        dayText.text = "Day: " + dayNumber;
        moneyText.text = "Money: $" + money;
        Debug.Log("Starting new day. Money: $" + money); // Debug log for starting new day
        customersServed = 0;
        restocksUsed = 0;
        inventory.ResetDailyStock();
        inventoryDisplay.RefreshInventory(inventory);
        currentCustomerNumber = 0;  // Reset the customer number at the start of the day
        customerOrders.Clear();  // Clear any previous day's customer orders
        StartCoroutine(DelayBeforeCustomerSpawn());
    }
private IEnumerator DelayBeforeCustomerSpawn()
{
    Debug.Log("Waiting 5 seconds before starting customer spawn...");
    yield return new WaitForSeconds(5f);  // Wait for 5 seconds
    Debug.Log("5 seconds passed, starting customer spawn...");
    StartCoroutine(SpawnCustomers());  // Start spawning customers after the delay
}


public void ServeCustomer(List<string> order)
{
    if (isOrderBeingProcessed)
    {
        Debug.Log("Order is already being processed. Skipping...");
        return; // Prevent multiple orders from being processed at the same time
    }

    Debug.Log("Serving customer with order: " + string.Join(", ", order)); // Debug log to confirm serving
    customerOrderDisplay.DisplayOrder(order, customerOrderText, inventory.prices); // Show order
    StartCoroutine(HandleCustomerOrder(order)); // Process the order
}

private IEnumerator HandleCustomerOrder(List<string> customerOrder)
{
    isOrderBeingProcessed = true; // Flag the order as being processed
    Debug.Log("Processing order: " + string.Join(", ", customerOrder));

    yield return new WaitForSeconds(5f);
    int orderValue = inventory.ProcessOrder(customerOrder); // Process the order with inventory

    if (orderValue > 0)
    {
        Debug.Log("Order processed successfully. Total value: $" + orderValue);
        money += orderValue; // Add the order value to money
        moneyText.text = "Money: $" + money.ToString("F2"); // Update UI with new money
        inventoryDisplay.RefreshInventory(inventory); // Refresh inventory display

        yield return new WaitForSeconds(2); // Simulate customer being served for 2 seconds
        customersServed++; // Increment the number of customers served
        Debug.Log("Customers served: " + customersServed);
    }
    else
    {
        messageText.text = "One or more customer items are out of stock!";
        yield return new WaitForSeconds(2); // Wait for the message to be displayed
        messageText.text = ""; // Clear message
        Debug.Log("Order could not be processed due to lack of stock.");
    }

    // Check if the day should end
    if (customersServed >= dailyCustomers)
    {
        Debug.Log("All customers served. Ending the day...");
        EndDay(); // End the day if all customers are served
    }

    isOrderBeingProcessed = false; // Reset the flag after order is processed
}

    // Coroutine to spawn customers
   private IEnumerator SpawnCustomers()
{
    while (!isDayOver && currentCustomerNumber < dailyCustomers)
    {
        currentCustomerNumber++;
        Debug.Log("Spawning customer " + currentCustomerNumber); // Debug log

        // Update the customer number display
        currentCustomerText.text = "Current Customer: " + currentCustomerNumber;

        // Show the "Current Customer" text and update it
        currentCustomerText.gameObject.SetActive(true);
        currentCustomerText.text = "Current Customer: " + currentCustomerNumber;

        // Generate a random order for the current customer
        List<string> order = GenerateOrder();
        customerOrders.Add(order);  // Store the order for this customer

        messageTwoText.text = "Customer " + currentCustomerNumber + " enters!";
        yield return new WaitForSeconds(2f);  // Wait 2 seconds before showing the message
        messageTwoText.text = "";  // Hide the enter message

        // Now serve the customer with the generated order
        ServeCustomer(order);

        yield return new WaitForSeconds(10f);  // Simulate 10 seconds spent in the store

        messageTwoText.text = "Customer " + currentCustomerNumber + " leaves!";
        yield return new WaitForSeconds(2f);  // Wait for 2 seconds before clearing the message
        messageTwoText.text = "";  // Hide the leave message

        // Clear the order display
        customerOrderDisplay.ClearOrder();
        currentCustomerText.gameObject.SetActive(false);

        yield return new WaitForSeconds(5f);  // Wait 5 seconds before the next customer spawns
    }
    currentCustomerText.gameObject.SetActive(false);
}


    // Helper function to generate a random order for each customer
    private List<string> GenerateOrder()
    {
        int orderSize = Random.Range(3, 6);
        List<string> order = new List<string>();

        List<string> items = new List<string>() { "Nougat Bar", "Chocolate Bar", "Gummies", "Slushie", "Beverage Can", "Popcorn", "Hotdog" };

        for (int i = 0; i < orderSize; i++)
        {
            string item = items[Random.Range(0, items.Count)];
            order.Add(item);
        }

        Debug.Log("Generated order: " + string.Join(", ", order)); // Debug log to check the order
        return order;
    }


    // Additional methods (Restock, PurchaseUpgrade, etc.) go here
    public void ToggleRegisterMenu()
    {
        registerMenuPanel.SetActive(!registerMenuPanel.activeSelf);
        Time.timeScale = registerMenuPanel.activeSelf ? 0 : 1;
    }

    void InitializeRegisterMenu()
    {
        increaseStockSizeButton.onClick.AddListener(() => PurchaseUpgrade("LargerInventory"));
        increaseRestocksButton.onClick.AddListener(() => PurchaseUpgrade("AdditionalRestock"));
        restockButton.onClick.AddListener(RestockSelectedItem);
        UpdateRegisterMenuButtons();
    }

    public void UpdateRegisterMenuButtons()
    {
        increaseStockSizeButton.interactable = money >= stockSizeCost && !upgradeManager.HasMaxUpgrade("LargerInventory");
        increaseRestocksButton.interactable = money >= dailyRestocksCost && !upgradeManager.HasMaxUpgrade("AdditionalRestock");
        restockButton.interactable = restocksUsed < restockLimit && dailyRestocksLeft > 0;
    }

    public void RestockSelectedItem()
    {
        string item = itemDropdown.options[itemDropdown.value].text;
        int quantity = 1;
        RestockItems(item, quantity);
    }

    public void RestockItems(string item, int quantity)
    {
        if (restocksUsed < restockLimit && inventory.RestockItem(item, quantity))
        {
            restocksUsed++;
            int previousMoney = money;
            money -= stockSizeCost;
            Debug.Log($"Money updated: ${previousMoney} -> ${money} (Spent ${stockSizeCost})"); // Debug log for money change
            moneyText.text = "Money: $" + money.ToString("F2");
            UpdateRegisterMenuButtons();
            inventoryDisplay.RefreshInventory(inventory);
        }
        else if (restocksUsed >= restockLimit && upgradeManager.additionalRestocksPurchased < upgradeManager.maxAdditionalRestocks)
        {
            if (restocksUsed < restockLimit + upgradeManager.additionalRestocksPurchased)
            {
                restocksUsed++;
                int previousMoney = money;
                money -= stockSizeCost;
                Debug.Log($"Money updated: ${previousMoney} -> ${money} (Spent ${stockSizeCost})"); // Debug log for money change
                moneyText.text = "Money: $" + money.ToString("F2");
                UpdateRegisterMenuButtons();
            }
        }
    }

    public void PurchaseUpgrade(string upgradeType)
    {
        if (upgradeManager.PurchaseUpgrade(upgradeType, ref money))
        {
            Debug.Log($"Money after upgrade purchase: ${money}"); // Debug log for money after upgrade purchase
            moneyText.text = "Money: $" + money.ToString("F2");

            if (upgradeType == "LargerInventory")
            {
                restockLimit++;
                inventoryDisplay.RefreshInventory(inventory);
            }
            else if (upgradeType == "AdditionalRestock")
            {
                dailyRestocksLeft++;
            }

            UpdateRegisterMenuButtons();
        }
    }

    public void UpdateMoneyText()
    {
        moneyText.text = "Money: $" + money.ToString("F2");
    }

    public void UpdateUpgradeTexts()
    {
        dailyRestocksRemainingText.text = "Daily Restocks Remaining: " + dailyRestocksLeft;
        stockSizeUpgradesRemainingText.text = "Stock Size Upgrades Remaining: " + (maxStockSizeReached ? "Max Reached" : "Available");
        dailyRestockLimitUpgradesRemainingText.text = "Daily Restock Limit Upgrades Remaining: " + (maxDailyRestocksReached ? "Max Reached" : "Available");
    }


    void EndDay()
    {
        isDayOver = true;
        int previousMoney = money;
        money -= 50;
        Debug.Log($"Money after end of day penalty: ${previousMoney} -> ${money} (Penalty: $50)"); // Debug log for money change
        if (money <= 0)
        {
            GameOver();
        }
        else
        {
            dayNumber++;
            StartNewDay();
        }
    }

    void GameOver()
    {
        gameOverMenu.SetActive(true);
    }

    void TogglePauseMenu()
    {
        pauseMenu.SetActive(!pauseMenu.activeSelf);
        Time.timeScale = pauseMenu.activeSelf ? 0 : 1;
    }
}

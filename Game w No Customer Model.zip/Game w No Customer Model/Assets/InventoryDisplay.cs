using UnityEngine;
using TMPro;

public class InventoryDisplay : MonoBehaviour
{
    public TMPro.TextMeshProUGUI inventoryTextUI;  
    public Inventory inventory;

    void Start()
    {
        RefreshInventory(inventory);
    }

    public void RefreshInventory(Inventory inventory)
    {
        string inventoryDetails = "";  

        foreach (var item in inventory.stock)
        {
            inventoryDetails += item.Key + ": " + item.Value + "\n";
        }

        inventoryTextUI.text = inventoryDetails; 
    }
}
